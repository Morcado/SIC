﻿namespace ProyectoSIC
{
    partial class GramaticaLexer
    {
    }
}
