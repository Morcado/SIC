﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoSIC {
	public class Programa {
		public List<Linea> lineas;
		public List<string> tabSim;

		public Programa() {
			lineas = new List<Linea>();
		}
	}
}
