﻿namespace ProyectoSIC
{
    partial class GramaticaParser
    {
    }
}
